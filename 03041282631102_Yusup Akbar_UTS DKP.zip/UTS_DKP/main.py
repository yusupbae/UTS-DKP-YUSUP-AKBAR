# PROGRAM ANALISIS DAN KLASIFIKASI DATA
# KELOMPOK F - INFORMASI/DATA

# Menyimpan 15 data asli
data_nilai = [
    42, 55, 61, 68, 73,
    79, 82, 87, 91, 64,
    58, 76, 84, 49, 95
]

# Menyimpan 5 data tambahan
data_tambahan = [59, 60, 77, 80, 100]

# Menggabungkan data untuk dianalisis
semua_data = data_nilai + data_tambahan

# Menghitung rata-rata dari data
# Menentukan kategori nilai dari data
# Mengurutkan nilai dari data

def rata_rata(data):
    total = 0
    for nilai in data:
        total += nilai
    return total / len(data)

def kategori(nilai):
    if nilai < 60:
        return "RENDAH"
    elif nilai < 80:
        return "SEDANG"
    else:
        return "TINGGI" 

def urutkan_nilai(data):
    return sorted(data)   

# Menghitung jumlah kategori
rendah = 0
sedang = 0
tinggi = 0

for nilai in semua_data:
    hasil = kategori(nilai)

    if hasil == "RENDAH":
        rendah += 1
    elif hasil == "SEDANG":
        sedang += 1
    else:
        tinggi += 1

# Menampilkan hasil analisis data

semua_data = data_nilai + data_tambahan

print("===== HASIL ANALISIS NILAI =====")

for i, nilai in enumerate(semua_data, start=1):
    print(i, ". Nilai =", nilai, "->", kategori(nilai))

# Menampilkan ringkasan hasil analisis data

print("\n===== RINGKASAN DATA =====")

print("Total data       :", len(semua_data))
print("Rata-rata        :", round(rata_rata(semua_data), 2))
print("Nilai tertinggi  :", max(semua_data))
print("Nilai terendah   :", min(semua_data))
print("Urutan nilai     :", urutkan_nilai(semua_data))
print("RENDAH           :", rendah)
print("SEDANG           :", sedang)
print("TINGGI           :", tinggi)

# PENGUJIAN PROGRAM

kasus_uji = [
    (59, "RENDAH"),
    (84, "TINGGI"),
    (61, "SEDANG"),
    (79, "SEDANG"),
    (80, "TINGGI"),
    (60, "SEDANG"),
    (42, "RENDAH"),
    (100, "TINGGI")
]

print("\n===== HASIL PENGUJIAN =====")

for nilai, harapan in kasus_uji:
    aktual = kategori(nilai)

    if aktual == harapan:
        status = "PASS"
    else:
        status = "FAIL"

    print("Nilai:", nilai,
          "| Harapan:", harapan,
          "| Aktual:", aktual,
          "|", status)